"""
    Plugin for ResolveURL
    Copyright (C) 2024 gujal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
from resolveurl import common
from resolveurl.lib import helpers
from resolveurl.resolver import ResolveUrl, ResolverError


def open_url(url):
    try:
        hdr = {'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', 
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'}
        req = urllib2.Request(url, headers=hdr)
        response = urllib2.urlopen(req)
        data = response.read().decode('utf-8')
        return data
    except:
        data = ''
        return data

def mediafire(url):
    data = open_url(url)
    link = re.compile('aria-label="Download file"\n.+?href="(.*?)"',re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
    return link[0]

def resolve(url):
    if 'mediafire' in url:
        try:
            resolved = mediafire(url)
        except:
            resolved = ''
    else:
        resolved = url
    return resolved    
