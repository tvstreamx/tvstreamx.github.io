# -*- coding: utf-8 -*-
import xml.etree.ElementTree as ET
import json
import base64
from helper import *
import re
from datetime import datetime, timedelta

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'

# --- Funções auxiliares (sem alterações) ---
def cliente(url):
    return requests.get(url,headers={'User-Agent': USER_AGENT})

def extract_info(url):
    parsed_url = urlparse(url)
    protocol = parsed_url.scheme
    host = parsed_url.hostname
    port = parsed_url.port or (80 if protocol == 'http' else 443)
    query_params = parse_qs(parsed_url.query)
    username = query_params.get('username', [None])[0]
    password = query_params.get('password', [None])[0]
    dns = f'{protocol}://{host}:{port}'
    return dns, username, password

def parselist(url):
    iptv = []
    try: url = requests.get(url).json()['url']
    except: pass      
    try:
        src = requests.get(url).text
        for i in src.split('\n'):
            i = i.strip()
            if 'http' in i:
                iptv.append(extract_info(i))
    except: pass
    return iptv

def remove_emojis(text):
    if not text: return ''
    try:
        if six.PY2:
            if not isinstance(text, unicode): text = text.decode("utf-8")
            highpoints = re.compile(u'[\u2600-\u26FF\u2700-\u27BF\u2B50-\u2B59\uD800-\uDBFF][\uDC00-\uDFFF]|[\U00010000-\U0010ffff]')
        else:
            highpoints = re.compile(r'[\u2600-\u26FF\u2700-\u27BF\u2B50-\u2B59\U00010000-\U0010ffff]', flags=re.UNICODE)
        text = highpoints.sub(r'', text)
    except: pass
    return text.replace('  ', ' ').strip()

# --- Classe API ---
class API:
    def __init__(self, dns, username, password):
        self.dns = dns
        self.player_api = f'{dns}/player_api.php?username={username}&password={password}'
        self.epg_url = f'{dns}/xmltv.php?username={username}&password={password}'
        self.play_url = f'{dns}/live/{username}/{password}/'
        self.play_movies = f'{dns}/movie/{username}/{password}/'
        self.play_series = f'{dns}/series/{username}/{password}/'
        self.adult_tags = ['xxx','xXx','XXX','adult','Adult','ADULT','adults','Adults','ADULTS','porn','Porn','PORN']
        self.hide_adult = getsetting('hidexxx') == 'true'
        # Define o caminho do diretório de cache
        self.cache_dir = os.path.join(profile, 'epg_cache')
        self.cache_path = os.path.join(self.cache_dir, f"epg_{re.sub(r'[^a-zA-Z0-9]', '_', self.dns)}.json")

    def http_json(self, url):
        try: return cliente(url).json()
        except: return None
        
    def http_content(self, url):
        try: return cliente(url).content
        except: return b''

    # --- FUNÇÕES DE EPG ATUALIZADAS ---
    def _parse_epg_time(self, time_str):
        try:
            dt_part = time_str[:14]
            offset_part = time_str[15:]
            dt_obj = datetime.strptime(dt_part, '%Y%m%d%H%M%S')
            if offset_part:
                signal = -1 if offset_part[0] == '+' else 1
                hours = int(offset_part[1:3])
                minutes = int(offset_part[3:5])
                offset = timedelta(hours=hours, minutes=minutes)
                dt_utc = dt_obj + (offset * signal)
                return dt_utc
            return dt_obj
        except:
            return None

    def _fetch_and_save_epg(self):
        log(f'[EPG] Baixando e processando EPG para: {self.dns}')
        xml_content = self.http_content(self.epg_url)
        if not xml_content:
            log(f'[EPG] ERRO: Falha ao baixar XMLTV de {self.dns}')
            return
        
        epg_dict = {}
        try:
            root = ET.fromstring(xml_content)
            for prog in root.findall('programme'):
                channel_id = prog.get('channel') 
                start_utc = self._parse_epg_time(prog.get('start'))
                stop_utc = self._parse_epg_time(prog.get('stop'))
                title_elem = prog.find('title')
                desc_elem = prog.find('desc')
                
                if channel_id and start_utc and stop_utc and title_elem is not None:
                    title = title_elem.text or ''
                    description = desc_elem.text if desc_elem is not None and desc_elem.text else ''
                    
                    epg_dict.setdefault(channel_id, []).append({
                        'start': start_utc.isoformat(), 
                        'stop': stop_utc.isoformat(), 
                        'title': title,
                        'desc': description
                    })
            for cid in epg_dict:
                epg_dict[cid].sort(key=lambda x: x['start'])
            
            # --- CORREÇÃO AQUI: Garante que o diretório de cache exista ---
            if not exists(self.cache_dir):
                mkdir(self.cache_dir)
                log(f"[EPG] Diretório de cache criado em: {self.cache_dir}")
            # ------------------------------------------------------------------

            cache_to_save = {'updated': datetime.now().isoformat(), 'data': epg_dict}
            with open(self.cache_path, 'w') as f:
                json.dump(cache_to_save, f)
            log(f'[EPG] Cache de EPG salvo com sucesso para {self.dns}')
        except Exception as e:
            log(f'[EPG] ERRO CRÍTICO ao processar e salvar EPG: {e}')
    
    def update_epg_cache(self):
        needs_update = True
        if exists(self.cache_path):
            try:
                with open(self.cache_path, 'r') as f:
                    cache_content = json.load(f)
                last_updated = datetime.fromisoformat(cache_content['updated'])
                if datetime.now() - last_updated < timedelta(hours=3):
                    needs_update = False
                    log(f"[EPG] Cache para {self.dns} está atualizado.")
            except:
                pass
        
        if needs_update:
            self._fetch_and_save_epg()

    def _read_epg_cache(self):
        if exists(self.cache_path):
            try:
                with open(self.cache_path, 'r') as f:
                    return json.load(f)['data']
            except:
                return {}
        return {}

    def _format_epg_for_channel(self, programs):
        if not programs: return ''
        now_utc = datetime.utcnow()
        now_prog, next_prog = None, None
        
        for i, prog in enumerate(programs):
            start_dt = datetime.fromisoformat(prog['start'])
            stop_dt = datetime.fromisoformat(prog['stop'])
            if start_dt <= now_utc < stop_dt:
                now_prog = prog
                if i + 1 < len(programs):
                    next_prog = programs[i+1]
                break
        
        desc_parts = []
        if now_prog:
            desc_parts.append(f"[B][COLOR deepskyblue]AGORA:[/COLOR][/B] {now_prog.get('title', '')}")
            now_desc = now_prog.get('desc', '')
            if now_desc:
                desc_parts.append(f"[I]{now_desc}[/I]")

        if next_prog:
            if now_prog: desc_parts.append('') 
            next_start_dt = datetime.fromisoformat(next_prog['start'])
            next_start_local = next_start_dt + (datetime.now() - datetime.utcnow())
            desc_parts.append(f"[B][COLOR gold]A SEGUIR:[/COLOR][/B] {next_prog.get('title', '')} ({next_start_local.strftime('%H:%M')})")
        
        return '\n'.join(desc_parts)

    # --- O RESTO DO CÓDIGO PERMANECE IGUAL ---
    def channels_category(self):
        itens = []
        url = f"{self.player_api}&action=get_live_categories"
        data = self.http_json(url)
        if data and isinstance(data, list):
            for cat in data:
                name = cat.get('category_name', 'Categoria Desconhecida')
                cat_id = cat.get('category_id')
                if cat_id and 'All' not in name:
                    if not self.hide_adult or not any(s in name for s in self.adult_tags):
                        itens.append((remove_emojis(name), f"{self.player_api}&action=get_live_streams&category_id={cat_id}"))
        return itens

    def channels_open(self,url):
        epg_data = self._read_epg_cache()
        itens = []
        data = self.http_json(url)
        if data and isinstance(data, list):
            for channel_data in data:
                stream_id = channel_data.get('stream_id')
                if stream_id:
                    name = channel_data.get('name', 'Canal Desconhecido')
                    link = f'{self.play_url}{stream_id}.m3u8'
                    thumb = channel_data.get('stream_icon', '')
                    epg_id = channel_data.get('epg_channel_id')
                    desc = ''
                    if epg_id and epg_data:
                        programs = epg_data.get(epg_id, [])
                        desc = self._format_epg_for_channel(programs)
                    itens.append((name, link, thumb, desc))
        return itens

    def series_cat(self):
        itens = []
        url = f"{self.player_api}&action=get_series_categories"
        data = self.http_json(url)
        if data and isinstance(data, list):
            for cat in data:
                name = cat.get('category_name', 'Categoria Desconhecida')
                cat_id = cat.get('category_id')
                if cat_id:
                    if not self.hide_adult or not any(s in name for s in self.adult_tags):
                        url_cat = f"{self.player_api}&action=get_series&category_id={cat_id}"
                        itens.append((remove_emojis(name), url_cat))
        return itens

    def series_list(self,url):
        itens = []
        data = self.http_json(url)
        if data and isinstance(data, list):
            for ser in data:
                name = ser.get('name', 'Série Desconhecida')
                series_id = ser.get('series_id')
                if series_id:
                    url_info = f"{self.player_api}&action=get_series_info&series_id={str(series_id)}"
                    thumb = ser.get('cover', '')
                    background_list = ser.get('backdrop_path', [''])
                    background = background_list[0] if background_list and background_list[0] else ''
                    plot = ser.get('plot', '')
                    releaseDate = ser.get('releaseDate', '')
                    cast = ser.get('cast', '')
                    rating = ser.get('rating_5based', '')
                    runtime = str(ser.get('episode_run_time', ''))
                    genre = ser.get('genre', '')
                    itens.append((name,url_info,thumb,background,plot,releaseDate,cast,rating,runtime,genre))
        return itens

    def series_seasons(self,url):
        itens = []
        ser_cat = self.http_json(url)
        if ser_cat and 'episodes' in ser_cat:
            info = ser_cat.get('info', {})
            thumb = info.get('cover', '')
            background_list = info.get('backdrop_path', [''])
            background = background_list[0] if background_list and background_list[0] else ''
            sorted_seasons = sorted(ser_cat['episodes'].keys(), key=lambda x: int(x))
            for season_num in sorted_seasons:
                name = f'Temporada {season_num}'
                url_ = f"{url}&season_number={season_num}"
                itens.append((name, url_, thumb, background))
        return itens

    def season_list(self,url):
        itens = []
        parsed_url = urlparse(url)
        query_params = parse_qs(parsed_url.query)
        series_id = query_params.get('series_id', [None])[0]
        season_number = query_params.get('season_number', [None])[0]
        if not series_id or not season_number: return []
        api_url = f"{self.player_api}&action=get_series_info&series_id={series_id}"
        ser_cat = self.http_json(api_url)
        if not ser_cat or 'episodes' not in ser_cat: return []
        info = ser_cat.get('info', {})
        episodes_data = ser_cat.get('episodes', {})
        if season_number in episodes_data:
            for ser in episodes_data[season_number]:
                ep_id = ser.get('id')
                if ep_id:
                    link = f"{self.play_series}{ep_id}.{ser.get('container_extension', 'mp4')}"
                    ep_num = ser.get('episode_num', '')
                    ep_title = ser.get('title', 'Episódio Desconhecido')
                    name = f"{ep_num}. {ep_title}" if ep_num else ep_title
                    ser_info = ser.get('info', {})
                    thumb = ser_info.get('movie_image', info.get('cover', ''))
                    plot = ser_info.get('plot', '')
                    releasedate = ser_info.get('releasedate', '')
                    duration_str = str(ser_info.get('duration', ''))
                    duration_secs = 0
                    if ':' in duration_str:
                        try:
                            parts = duration_str.split(':')
                            duration_secs = int(parts[0])*3600 + int(parts[1])*60 + int(parts[2])
                        except: pass
                    elif duration_str.isdigit():
                        duration_secs = int(duration_str)
                    cast = info.get('cast', '')
                    rating = info.get('rating_5based', '')
                    genre = info.get('genre', '')
                    background = info.get('backdrop_path', [''])[0] if info.get('backdrop_path') else ''
                    itens.append((name, link, thumb, background, plot, releasedate, cast, rating, str(duration_secs), genre))
        return itens

    def vod2(self):
        itens = []
        url = f"{self.player_api}&action=get_vod_categories"
        data = self.http_json(url)
        if data and isinstance(data, list):
            for cat in data:
                name = cat.get('category_name', 'Categoria Desconhecida')
                cat_id = cat.get('category_id')
                if cat_id:
                    if not self.hide_adult or not any(s in name for s in self.adult_tags):
                        link = f"{self.player_api}&action=get_vod_streams&category_id={cat_id}"
                        itens.append((remove_emojis(name), link))
        return itens

    def Vodlist(self,url):
        itens = []
        data = self.http_json(url)
        if data and isinstance(data, list):
            for cat in data:
                stream_id = cat.get('stream_id')
                if stream_id:
                    thumb = cat.get('stream_icon', '')
                    link = f"{self.play_movies}{stream_id}.{cat.get('container_extension', 'mp4')}"
                    name = str(cat.get('name', 'Filme Desconhecido'))
                    if not self.hide_adult or not any(s in name for s in self.adult_tags):
                        itens.append((name,link,thumb))
        return itens