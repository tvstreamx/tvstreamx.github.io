# -*- coding: utf-8 -*-
from helper import *
from doh_client import requests
import xtream
import github
import re
import threading # Adicionado para EPG em segundo plano

# Função de contexto não muda
def context_iptv_info(item):
    plugin = 'plugin://' + addonID + '/iptv_info/' + quote_plus(urlencode(item))
    context = [(item['name'], 'RunPlugin(%s)'%plugin)]
    return context

channels_api_gratis = 'https://gist.github.com/tvstreamx/546d487ecb293ae9d5562b86c169f59a'
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
}
desc_oneplay = '''
Para trabalhar em equipe precisamos ter empatia, transparência, solidariedade e muita lealdade, esses ingredientes são necessários para o sucesso em grupo.

[B][COLOR cyan]REPOSITÓRIO OFICIAL TVSTREAMX[/COLOR][/B]
[COLOR blue]https://tvstreamx.github.io/tvstreamx[/COLOR]
    '''

try:
    class Donate_(xbmcgui.WindowDialog):
        def __init__(self):
            try:
                self.image = xbmcgui.ControlImage(440, 128, 400, 400, translate(os.path.join(homeDir, 'resources', 'images','qrcode.png')))
                self.text = xbmcgui.ControlLabel(x=150,y=570,width=1100,height=25,label='[B][COLOR yellow]SE ESSE ADD-ON LHE AGRADA, FAÇA UMA DOAÇÃO VIA PIX ACIMA E MANTENHA ESSE SERVIÇO ATIVO[/COLOR][/B]',textColor='yellow')
                self.text2 = xbmcgui.ControlLabel(x=495,y=600,width=1000,height=25,label='[B][COLOR yellow]PRESSIONE VOLTAR PARA SAIR[/COLOR][/B]',textColor='yellow')
                self.addControl(self.image)
                self.addControl(self.text)
                self.addControl(self.text2)
            except:
                pass
except:
    pass

def donate_question():
    q = yesno('', 'Deseja fazer uma doação do desenvolvedor?', nolabel='NÃO', yeslabel='SIM')
    if q:
        dialog2('AVISO', 'A DOAÇÃO É UMA AJUDA AO DESENVOLVEDOR E NÃO DA DIREITO AO VIP!')
        dialog_donate = Donate_()
        dialog_donate.doModal()

def desc_vip():
    text = ''
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0'
    try:
        r = requests.get('https://raw.githubusercontent.com/BLACKSHEEPcolabdev/add-on/refs/heads/master/info_tvstreamx.txt', headers={'User-Agent': user_agent})
        text += r.content.decode('utf-8')
    except:
        pass
    return text

def first_acess():
    first = getsetting('first')
    if first == 'true':
        q = yesno('', 'Deseja ativar os conteudos Adultos?')
        if q:
            setsetting('hidexxx', 'true')
            adult_password = input_text('Defina a senha Parental:')
            if not adult_password:
                adult_password = ''
            setsetting('parental_password', str(adult_password))
        else:
            setsetting('hidexxx', 'false')
        setsetting('first', 'false')

### ROTA PRINCIPAL - MENU ###
@route('/')
def list_categories():
    setcontent('movies')
    addMenuItem({'name': '[COLOR yellow]:::[/COLOR]BEM-VINDOS AO TVSTREAMX[COLOR yellow]:::[/COLOR]', 'description': desc_oneplay}, destiny='')
#    if getsetting('exibirvip') == 'true':
#        addMenuItem({'name': 'VIP', 'description': desc_vip(), 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','vip.png'))}, destiny='')
    
    addMenuItem({'name': 'TVSTREAMX - CANAIS AO VIVO', 'description': 'Canais de TV ao vivo', 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','tv.png'))}, destiny='/iptv_entry')
    addMenuItem({'name': 'TVSTREAMX - FILMES', 'description': 'Filmes do provedor IPTV', 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','filmes.png'))}, destiny='/vod_entry')
    addMenuItem({'name': 'TVSTREAMX - SÉRIES', 'description': 'Séries do provedor IPTV', 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','series.png'))}, destiny='/series_entry')
    
#    addMenuItem({'name': 'DOAÇÃO', 'description': '', 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','doacao.png'))}, destiny='/donate')
    addMenuItem({'name': 'CONFIGURAÇÕES', 'description': '', 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','configuracoes.png'))}, destiny='/config')
    end(False)
    setview('List')

# --- PONTO DE ENTRADA PARA TV AO VIVO ---
@route('/iptv_entry')
def iptv_entry(param):
    first_acess()
    chan = github.last_gist(channels_api_gratis)
    iptv = xtream.parselist(chan)
    if iptv:
        for n, (dns, username, password) in enumerate(iptv):
            n = n + 1
            item_context = {'name': 'INFO DA LISTA {0}'.format(str(n)), 'dns': dns, 'username': str(username), 'password': str(password)}
            addMenuItem({'name': 'TVSTREAMX - CANAIS {0}'.format(str(n)), 'description': 'Assista os melhores canais', 'tipo': 'gratis', 'dns': dns, 'username': str(username), 'password': str(password), 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','tv.png'))}, context=context_iptv_info(item_context), destiny='/cat_channels')
        end()
        setview('WideList')
    else:
        notify('Falha ao exibir listas')

# --- PONTO DE ENTRADA PARA FILMES (VOD) ---
@route('/vod_entry')
def vod_entry(param):
    first_acess()
    chan = github.last_gist(channels_api_gratis)
    iptv = xtream.parselist(chan)
    if iptv:
        for n, (dns, username, password) in enumerate(iptv):
            n = n + 1
            item_context = {'name': 'INFO DA LISTA {0}'.format(str(n)), 'dns': dns, 'username': str(username), 'password': str(password)}
            addMenuItem({'name': 'TVSTREAMX - FILMES {0}'.format(str(n)), 'description': 'Ver filmes deste servidor', 'dns': dns, 'username': str(username), 'password': str(password), 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','filmes.png'))}, context=context_iptv_info(item_context), destiny='/vod_categories')
        end()
        setview('WideList')
    else:
        notify('Falha ao exibir listas')
        
# --- PONTO DE ENTRADA PARA SÉRIES ---
@route('/series_entry')
def series_entry(param):
    first_acess()
    chan = github.last_gist(channels_api_gratis)
    iptv = xtream.parselist(chan)
    if iptv:
        for n, (dns, username, password) in enumerate(iptv):
            n = n + 1
            item_context = {'name': 'INFO DA LISTA {0}'.format(str(n)), 'dns': dns, 'username': str(username), 'password': str(password)}
            addMenuItem({'name': 'TVSTREAMX - SÉRIE {0}'.format(str(n)), 'description': 'Ver séries deste servidor', 'dns': dns, 'username': str(username), 'password': str(password), 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','series.png'))}, context=context_iptv_info(item_context), destiny='/series_categories')
        end()
        setview('WideList')
    else:
        notify('Falha ao exibir listas')

### ROTAS DE IPTV (AO VIVO) ###
@route('/cat_channels')
def cat_channels(param):
    dns, username, password, tipo = param['dns'], param['username'], param['password'], param['tipo']
    if tipo == 'vip':
        boas_vindas = '[B]::: O MELHOR ADD-ON:::[/B]'
    else:
        boas_vindas = '[B]::: FREE :::[/B]'
    
    api = xtream.API(dns, username, password)

    # Dispara a verificação/download do EPG em segundo plano
    # Assim, a interface não fica travada esperando.
    thread_epg = threading.Thread(target=api.update_epg_cache)
    thread_epg.start()

    cat = api.channels_category()
    if cat:
        for name, url in cat:
            addMenuItem({'name': name, 'dns': dns, 'username': username, 'password': password, 'url': url, 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','tv.png'))}, destiny='/open_channels')
        end()
        setview('WideList')
    else:
        notify('Servidor offline ou sem canais')

@route('/open_channels')
def open_channels(param):
    grupo, dns, username, password, url = param['name'], param['dns'], param['username'], param['password'], param['url']
    if re.search("Adult",grupo,re.IGNORECASE) or re.search("A Casa das Brasileirinhas",grupo,re.IGNORECASE) or re.search("XXX",grupo,re.IGNORECASE):
        password1 = getsetting('parental_password')
        password2 = input_text('Senha Parental:')
        if str(password1) != str(password2):
            dialog('Senha errada'); return
            
    open_ = xtream.API(dns, username, password).channels_open(url)
    if open_:
        setcontent('movies')
        addMenuItem({'name': f'[B]::: {grupo} :::[/B]'}, destiny='')
        for name, link, thumb, desc in open_:
            addMenuItem({'name': name, 'description': desc, 'iconimage': thumb, 'url': link}, destiny='/play_proxy', folder=False)
        end()
        setview('List')
    else:
        notify('Categoria vazia ou indisponível')

### ROTAS DE VOD (FILMES) ###
@route('/vod_categories')
def vod_categories(param):
    dns, username, password = param['dns'], param['username'], param['password']
    api = xtream.API(dns, username, password)
    categories = api.vod2()
    if categories:
        for name, url in categories:
            addMenuItem({'name': name, 'dns': dns, 'username': username, 'password': password, 'url': url, 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','filmes.png'))}, destiny='/vod_list')
        end()
        setview('WideList')
    else:
        notify('Servidor sem categorias de Filmes (VOD).')

@route('/vod_list')
def vod_list(param):
    dns, username, password, url = param['dns'], param['username'], param['password'], param['url']
    api = xtream.API(dns, username, password)
    movies = api.Vodlist(url)
    if movies:
        setcontent('movies')
        for name, link, thumb in movies:
            addMenuItem({'name': name, 'url': link, 'iconimage': thumb, 'playable': 'true'}, destiny='/play_direct', folder=False)
        end()
        setview('List')
    else:
        notify('Categoria vazia.')

### ROTAS DE SÉRIES ###
@route('/series_categories')
def series_categories(param):
    dns, username, password = param['dns'], param['username'], param['password']
    api = xtream.API(dns, username, password)
    categories = api.series_cat()
    if categories:
        for name, url in categories:
            addMenuItem({'name': name, 'dns': dns, 'username': username, 'password': password, 'url': url, 'iconimage': translate(os.path.join(homeDir, 'resources', 'images','series.png'))}, destiny='/series_list')
        end()
        setview('WideList')
    else:
        notify('Servidor sem categorias de Séries.')

@route('/series_list')
def series_list(param):
    dns, username, password, url = param['dns'], param['username'], param['password'], param['url']
    api = xtream.API(dns, username, password)
    series = api.series_list(url)
    if series:
        setcontent('tvshows')
        for name, url_info, thumb, background, plot, releaseDate, cast, rating, runtime, genre in series:
            addMenuItem({'name': name, 'description': plot, 'iconimage': thumb, 'fanart': background, 'year': releaseDate.split('-')[0] if releaseDate else '', 'genre': genre, 'dns': dns, 'username': username, 'password': password, 'url': url_info, 'mediatype': 'tvshow'}, destiny='/series_seasons')
        end()
        setview('List')
    else:
        notify('Categoria de séries vazia.')

@route('/series_seasons')
def series_seasons(param):
    dns, username, password, url = param['dns'], param['username'], param['password'], param['url']
    api = xtream.API(dns, username, password)
    seasons = api.series_seasons(url)
    if seasons:
        setcontent('seasons')
        for name, url_season, thumb, background in seasons:
            season_number_match = re.search(r'\d+', name)
            season_number = season_number_match.group(0) if season_number_match else ''
            addMenuItem({'name': name, 'iconimage': thumb, 'fanart': background, 'dns': dns, 'username': username, 'password': password, 'url': url_season, 'season': season_number, 'mediatype': 'season'}, destiny='/series_episodes')
        end()
        setview('List')
    else:
        notify('Não foi possível carregar as temporadas.')

@route('/series_episodes')
def series_episodes(param):
    dns, username, password, url = param['dns'], param['username'], param['password'], param['url']
    api = xtream.API(dns, username, password)
    episodes = api.season_list(url)
    if episodes:
        setcontent('episodes')
        for name, link, thumb, background, plot, releasedate, cast, rating, duration, genre in episodes:
            addMenuItem({'name': name, 'url': link, 'iconimage': thumb, 'fanart': background, 'description': plot, 'duration': duration, 'year': releasedate.split('-')[0] if releasedate else '', 'mediatype': 'episode', 'playable': 'true'}, destiny='/play_direct', folder=False)
        end()
        setview('WideList')
    else:
        notify('Temporada vazia.')

### ROTAS DE REPRODUÇÃO ###
@route('/play_proxy')
def player_hlsretry(param):
    name, url = param.get('name', ''), param.get('url', '')
    iconimage, description = param.get('iconimage', ''), param.get('description', '')
    if int(getsetting('tipocanais')) == 0:
        try:
            import hlsretry
            proxy_url = f'http://{hlsretry.HOST_NAME}:{hlsretry.PORT_NUMBER}/?url={quote(url)}'
            hlsretry.XtreamProxy().start()
        except Exception as e:
            infoDialog(f'Erro no proxy HLS: {e}', iconimage='ERROR'); return
    else:
        try:
            import tsdownloader
            proxy_url = f'http://{tsdownloader.HOST_NAME}:{tsdownloader.PORT_NUMBER}/?url={quote(url)}'
            tsdownloader.XtreamProxyTS().start()
        except Exception as e:
            infoDialog(f'Erro no proxy TS: {e}', iconimage='ERROR'); return
    play_video({'name': name, 'url': proxy_url, 'iconimage': iconimage, 'description': description})

@route('/play_direct')
def play_direct(param):
    name, url = param.get('name', ''), param.get('url', '')
    iconimage, description = param.get('iconimage', ''), param.get('description', '')
    play_video({'name': name, 'url': url, 'iconimage': iconimage, 'description': description, 'playable': 'true'})

### ROTAS DE UTILIDADE ###
@route('/donate')
def donate_func(param):
    donate_question()

@route('/config')
def config(param):
    opensettings()

@route('/iptv_info')
def iptv_info(param):
    dns, username, password = param.get('dns'), param.get('username'), param.get('password')
    itens = xtream.API(dns,username,password).account_info()
    if itens:
        msg = '\n'.join([f'{param.get("name")}:'] + itens)
        dialog_text(msg)
    else:
        dialog('Lista offline')