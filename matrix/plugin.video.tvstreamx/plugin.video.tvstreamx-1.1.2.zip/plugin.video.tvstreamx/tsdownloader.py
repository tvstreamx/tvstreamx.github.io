# -*- coding: utf-8 -*-
import os
import binascii
import socket
import threading
from six import PY3
if PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, unquote_plus, quote_plus
else:
    from urlparse import urlparse, parse_qs
    from urllib import quote, unquote, unquote_plus, quote_plus
import requests
import logging
import time
from doh_client import requests

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Evento para sinalizar parada do servidor
stop_event = threading.Event()

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))
        local_ip = s.getsockname()[0]
    except Exception:
        local_ip = '127.0.0.1'
    finally:
        try:
            s.close()
        except:
            pass
    return local_ip

def log(msg):
    logger.info(msg)

HOST_NAME = get_local_ip()
PORT_NUMBER = 57360
url_proxy = 'http://{0}:{1}/?url='.format(HOST_NAME, PORT_NUMBER)

global HEADERS_BASE, STOP_SERVER, stop_user
HEADERS_BASE = {}
STOP_SERVER = False
stop_user = False

class XtreamCodes:
    def set_headers(self, url):
        global HEADERS_BASE
        headers_default = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0',
            'Connection': 'keep-alive'
        }
        headers = {}
        if 'User-Agent' in url:
            try:
                user_agent = url.split('User-Agent=')[1]
                try:
                    user_agent = user_agent.split('&')[0]
                except:
                    pass
                user_agent = unquote_plus(user_agent)
                if 'Mozilla' in user_agent:
                    headers['User-Agent'] = user_agent
            except:
                pass
        if 'Referer' in url:
            try:
                referer = url.split('Referer=')[1]
                try:
                    referer = referer.split('&')[0]
                except:
                    pass
                referer = unquote_plus(referer)
                headers['Referer'] = referer
            except:
                pass
        if 'Origin' in url:
            try:
                origin = url.split('Origin=')[1]
                try:
                    origin = origin.split('&')[0]
                except:
                    pass
                origin = unquote_plus(origin)
                headers['Origin'] = origin
            except:
                pass
        if headers:
            headers.update({'Connection': 'keep-alive'})
            HEADERS_BASE = headers
        else:
            HEADERS_BASE = headers_default



    def loop_ts(self, self_server, url):
        global HEADERS_BASE
        global STOP_SERVER
        global stop_user
        try:
            for i in range(10):
                if stop_event.is_set() or STOP_SERVER:
                    log('Parando streaming TS')
                    break                    
                count = i + 1
                HEADERS_BASE['User-Agent'] = binascii.b2a_hex(os.urandom(20))[:32]
                r = requests.get(url, headers=HEADERS_BASE, allow_redirects=True, stream=True, verify=False)
                code = r.status_code
                log('Status Code: %s' % str(code))
                if code == 200:                    
                    try:
                        for chunk in r.iter_content(chunk_size=8192):
                            if stop_event.is_set() or STOP_SERVER:
                                log('Parando streaming TS')
                                break
                            if chunk:                     
                                try:
                                    self_server.conn.sendall(chunk)
                                except:
                                    stop_user = True
                                    break
                    except:
                        pass
                else:
                    if stop_user or stop_event.is_set() or STOP_SERVER:
                        break
                    elif count == 7:
                        break
        except:
            pass

    def send_ts(self, self_server, url):
        global HEADERS_BASE, STOP_SERVER, stop_user
        self_server.send_header('Content-type', 'video/mp2t')
        self_server.end_headers()         
        while not stop_event.is_set() or not STOP_SERVER or not stop_user:
            self.loop_ts(self_server, url)

    def parse_url(self, url):
        parsed_url = urlparse(url)
        return parsed_url.scheme, parsed_url.hostname, parsed_url.port

class ProxyHandler(XtreamCodes):
    def __init__(self, conn, addr, server):
        self.conn = conn
        self.addr = addr
        self.server = server
        self.path = ""
        self.request_method = ""

    def parse_request(self, request):
        parts = request.split(b' ')
        self.request_method = parts[0].decode()

    def parse_request2(self, request):
        parts = request.split(b' ')
        if len(parts) >= 2:
            self.path = parts[1].decode()

    def send_response(self, code, message=None):
        response = "HTTP/1.1 {0} {1}\r\n".format(code, message if message else '')
        self.conn.sendall(response.encode())

    def send_header(self, keyword, value):
        header = "{0}: {1}\r\n".format(keyword, value)
        self.conn.sendall(header.encode())

    def end_headers(self):
        self.conn.sendall(b"\r\n")

    def extract_header(self, request_data, header_name):
        header_lines = request_data.split(b'\r\n')
        for line in header_lines:
            if header_name in line:
                return line
        return None

    def get_range(self, request_data, content_length):
        range_header = self.extract_header(request_data, b'Range:')
        if range_header:
            parts = range_header.split(b"-")
            start = int(parts[0].split(b'=')[-1])
            end = int(parts[1]) if parts[1] else content_length - 1
            return start, end
        return 0, content_length - 1

    def stream_video(self, video_url, request_data):
        try:
            video_url = video_url.split('|')[0]
        except:
            pass
        try:
            video_url = video_url.split('%7C')[0]
        except:
            pass
        global HEADERS_BASE
        headers = HEADERS_BASE
        try:
            response = requests.head(video_url, headers=headers)
            if response.status_code == 200:
                content_length = int(response.headers.get('Content-Length', 0))
                start, end = self.get_range(request_data, content_length)
                headers['Range'] = f'bytes={start}-{end}'
                response = requests.get(video_url, headers=headers, stream=True)
                if response.status_code in (200, 206):
                    self.send_partial_response(206, response.headers, content_length, response.iter_content(chunk_size=1024), start, end)
                else:
                    self.send_response(404)
            else:
                self.send_response(404)
        except Exception as e:
            log(f'Erro no streaming video: {str(e)}')
            self.send_response(500)

    def send_partial_response(self, status_code, headers, content_length, content_generator, start, end):
        self.send_response(status_code)
        self.send_header("Accept-Ranges", "bytes")
        if start is not None:
            self.send_header("Content-Range", f"bytes {start}-{end}/{content_length}")
        for key, value in headers.items():
            self.send_header(key, value)
        self.end_headers()
        for chunk in content_generator:
            if STOP_SERVER:
                break
            try:
                self.conn.sendall(chunk)
            except:
                pass

    def handle_request(self):
        global HEADERS_BASE, STOP_SERVER, stop_user
        request_data = self.conn.recv(1024)
        self.parse_request(request_data)
        self.parse_request2(request_data)
        if self.request_method == 'HEAD':
            self.send_response(200)
        elif self.path == "/stop":
            self.send_response(200)
            STOP_SERVER = True
            stop_user = True
            HEADERS_BASE = {}
            stop_event.set()
            self.server.stop_server()
        elif self.path == "/reset":
            self.send_response(200)
            HEADERS_BASE = {}
            stop_user = False
        elif self.path == '/check':
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.conn.sendall(b"Hello, world!")
        else:
            url_path = unquote_plus(self.path)
            try:
                url_path = url_path.replace('VIDEO_TS.IFO', '')
            except:
                pass
            self.set_headers(url_path)
            url_parts = urlparse(url_path)
            query_params = parse_qs(url_parts.query)
            if 'url' in query_params:
                url = url_path.split('url=')[1].split('|')[0]
            else:
                url = url_path
            # convert m3u8 to mpegts
            url = url.replace('.m3u8', '').replace('live/', '')
            if '.mp4' in url and '.m3u8' not in url and '.ts' not in url:
                self.stream_video(url, request_data)
            elif '.ts' in url:
                self.send_response(200)
                log('URL TS: {0}'.format(url))
                self.send_ts(self, url)
            else:
                self.send_response(200)
                log('URL TS: {0}'.format(url))
                self.send_ts(self, url)
        self.conn.close()



class SocketServer:
    def __init__(self):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.server_socket.bind((HOST_NAME, PORT_NUMBER))
        except Exception as e:
            log('Erro ao bindar socket: {0}'.format(str(e)))
            raise
        self.server_socket.listen(10)

    def serve_forever(self):
        global STOP_SERVER
        log('Server started on http://{0}:{1}'.format(HOST_NAME, PORT_NUMBER))
        try:
            while not stop_event.is_set():
                self.server_socket.settimeout(1)
                try:
                    conn, addr = self.server_socket.accept()
                    handler = ProxyHandler(conn, addr, self)
                    thread = threading.Thread(target=handler.handle_request)
                    if PY3:
                        thread.daemon = True
                    else:
                        thread.setDaemon(True)
                    thread.start()
                except socket.timeout:
                    continue
                except Exception as e:
                    log('Error accepting connection: {}'.format(str(e)))
                    if stop_event.is_set():
                        break
        except KeyboardInterrupt:
            pass
        finally:
            self.stop_server()

    def stop_server(self):
        log('Encerrando servidor')
        stop_event.set()
        try:
            self.server_socket.close()
        except:
            pass
        log('Servidor socket encerrado')

def loop_server():
    server = SocketServer()
    server.serve_forever()

def monitor():
    try:
        try:
            from kodi_six import xbmc
        except:
            import xbmc
        monitor = xbmc.Monitor()
        while not monitor.waitForAbort(3) and not stop_event.is_set():
            pass
        log('Encerrando proxy server via monitor')
        url = 'http://{0}:{1}/stop'.format(HOST_NAME, PORT_NUMBER)
        try:
            requests.get(url, timeout=4)
        except:
            pass
        log('Proxy encerrado')
    except Exception as e:
        log('Erro no monitor: {}'.format(str(e)))

class XtreamProxyTS:
    def reset(self):
        try:
            url = 'http://{0}:{1}/reset'.format(HOST_NAME, PORT_NUMBER)
            r = requests.get(url, timeout=3)
            log('Proxy resetado')
        except Exception as e:
            log('Erro ao resetar proxy: {}'.format(str(e)))

    def check_service(self):
        try:
            url = 'http://{0}:{1}/check'.format(HOST_NAME, PORT_NUMBER)
            r = requests.head(url, timeout=3)
            return r.status_code == 200
        except:
            return False

    def start_(self):
        log('Iniciando Xtream Proxy - TSDOWNLOADER')
        status = self.check_service()
        if not status:
            proxy_service = threading.Thread(target=loop_server)         
            monitor_service = threading.Thread(target=monitor)
            if PY3:
                proxy_service.daemon = True
                monitor_service.daemon = True
            else:
                proxy_service.setDaemon(True)
                monitor_service.daemon = True
            proxy_service.start()               
            monitor_service.start()
            log('Proxy iniciado em: {0}'.format(url_proxy))
            while not stop_event.is_set():
                time.sleep(1)
        else:
            self.reset()    

    def start(self):
        threading.Thread(target=self.start_).start()


# if __name__ == '__main__':
#     XtreamProxyTS().start()

